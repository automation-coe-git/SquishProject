# Desktop-APP
<br>
<--
<br>
Desktop pos application created with Java 8, PGAdmin DB, Swing GUI, Jframe (no Servers needed).
<br>
Download the viewMyDesktopApp.jar file to view this application.
<br>
---------------------------------------------------------------# WIP-------------------------------------------------


# Login Panel
![login-panel](https://user-images.githubusercontent.com/28536965/51454791-95b92100-1d14-11e9-877e-ccfcbf07cbcf.JPG)
# Registration Panel
![registration-panel](https://user-images.githubusercontent.com/28536965/51454792-95b92100-1d14-11e9-9576-dcbc1fd81a03.JPG)
# Vegitables Panel
![vegitables-panel](https://user-images.githubusercontent.com/28536965/51454783-95208a80-1d14-11e9-8638-2118d0617be6.JPG)
# Wines Panel
![wines-panel](https://user-images.githubusercontent.com/28536965/51454784-95208a80-1d14-11e9-8bca-47abdf94bdf2.JPG)
# Beer Panel
![beer-panel](https://user-images.githubusercontent.com/28536965/51454785-95208a80-1d14-11e9-9899-1d76dc5843ea.JPG)
# Clothing Panel
![clothing-panel](https://user-images.githubusercontent.com/28536965/51454786-95208a80-1d14-11e9-94e3-8502b52714a4.JPG)
# Fruits Panel
![fruits-panel](https://user-images.githubusercontent.com/28536965/51454787-95208a80-1d14-11e9-824f-9f614fe1c776.JPG)
# Sale Panel
![items-on-sale-panel](https://user-images.githubusercontent.com/28536965/51454788-95208a80-1d14-11e9-9e7c-a8a7389c82bc.JPG)
# Jewellery Panel
![jewellery-panel](https://user-images.githubusercontent.com/28536965/51454789-95208a80-1d14-11e9-9738-430d2064028a.JPG)
# Shoes Panel
![shoes-panel](https://user-images.githubusercontent.com/28536965/51454793-95b92100-1d14-11e9-953b-ceec02124a12.JPG)
# Soft Drinks Panel
![soft-drinks-panel](https://user-images.githubusercontent.com/28536965/51454795-95b92100-1d14-11e9-9a24-029c732856e2.JPG)

      
